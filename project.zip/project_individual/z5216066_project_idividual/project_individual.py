import cv2
import numpy as np
from sklearn.model_selection import train_test_split
from scipy.cluster.vq import *
from sklearn.svm import LinearSVC
from sklearn import metrics
from sklearn.ensemble import RandomForestClassifier


def read_img(path, num):
    list_img = []
    label_img = []
    if num == 165:
        for i in range(num):
            if i < 9:
                file_name = path + 'ara2013_plant00' + str(i + 1) + '_rgb.png'
            elif 9 <= i < 99:
                file_name = path + 'ara2013_plant0' + str(i + 1) + '_rgb.png'
            elif 99 <= i < 999:
                file_name = path + 'ara2013_plant' + str(i + 1) + '_rgb.png'
            # print(file_name)
            img = cv2.imread(file_name)
            img_resize = cv2.resize(img, (300,300),interpolation=cv2.INTER_CUBIC)
            list_img.append(img_resize)
            label_img.append(0)
    if num == 62:
        for i in range(num):
            if i < 9:
                file_name = path + 'tobacco_plant00' + str(i + 1) + '_rgb.png'
            elif 9 <= i < 99:
                file_name = path + 'tobacco_plant0' + str(i + 1) + '_rgb.png'
            elif 99 <= i < 999:
                file_name = path + 'tobacco_plant' + str(i + 1) + '_rgb.png'
            # print(file_name)
            img = cv2.imread(file_name)
            img_resize = cv2.resize(img, (300,300),interpolation=cv2.INTER_CUBIC)
            list_img.append(img_resize)
            label_img.append(1)
    return list_img, label_img

def SURF_img(list_img):
    list_features = []
    list_descriptors = []
    surf = cv2.xfeatures2d_SURF.create(hessianThreshold=600)
    for img in list_img:
        keypoints, des = cv2.xfeatures2d_SURF.detectAndCompute(surf, img, None)
        list_features.append(des)
        # list_descriptors.append(fea for fea in des)
    for feature in list_features:
        for fea in feature:
            list_descriptors.append(fea)
    return list_features,list_descriptors

def data_argument(list_img, list_label):
    list_img_flipped = []
    list_label_flipped = []
    for i in range(len(list_img)):
        new_img = np.fliplr(list_img[i])
        list_img_flipped.append(new_img)
        list_label_flipped.append(list_label[i])
    return list_img_flipped, list_label_flipped

#ara2013_plant001_rgb
# get the path
path_canon = 'Plant/Ara2013-Canon/'
path_tobacco = 'Plant/Tobacco/'
dict_imgs = {}

# get the list of images and labels
list_img_canon, list_label_canon= read_img(path_canon,165)
list_img_tobacco,list_label_tobacco= read_img(path_tobacco,62)

# store images and labels in a dictionary
dict_imgs['Arabidopsis'] = []
dict_imgs['Arabidopsis'].append(list_img_canon)
dict_imgs['Arabidopsis'].append(list_label_canon)
dict_imgs['tobacco'] = []
dict_imgs['tobacco'].append(list_img_tobacco)
dict_imgs['tobacco'].append(list_label_tobacco)

# print(len(dict_imgs['Arabidopsis'][0]),len(dict_imgs['Arabidopsis'][1]))
# print(len(dict_imgs['tobacco'][0]),len(dict_imgs['tobacco'][1]))

# data argument
list_canon_flipped, list_label_flipped_canon = data_argument(dict_imgs['Arabidopsis'][0],dict_imgs['Arabidopsis'][1])
list_tobacco_flipped, list_label_flipped_tobacco = data_argument(dict_imgs['tobacco'][0],dict_imgs['tobacco'][1])

# split train set and test set
# data = dict_imgs['Arabidopsis'][0] + dict_imgs['tobacco'][0] + dict_imgs['Arabidopsis'][0] + dict_imgs['tobacco'][0]
# labels = dict_imgs['Arabidopsis'][1] + dict_imgs['tobacco'][1] + dict_imgs['Arabidopsis'][1] + dict_imgs['tobacco'][1]
# x_train, x_test, y_train, y_test = train_test_split(data,labels,test_size=0.4)


# test data argument
data = dict_imgs['Arabidopsis'][0] + dict_imgs['tobacco'][0] + list_canon_flipped + list_tobacco_flipped
labels = dict_imgs['Arabidopsis'][1] + dict_imgs['tobacco'][1]+ list_label_flipped_canon + list_label_flipped_tobacco
x_train, x_test, y_train, y_test = train_test_split(data,labels,test_size=0.4)



#build feature using SURF
list_features,list_descriptors = SURF_img(x_train)
# print(list_features)
# print(len(list_features))

vocabulary, variance = kmeans(list_descriptors, 100, 1)
# print(len(vocabulary))
img_features = np.zeros((len(list_features),100),'float32')
for idx in range(len(list_features)):
    words, distance = vq(list_features[idx],vocabulary)
    for w in words:
        img_features[idx][w] += 1

# create a Linear model
# clf = LinearSVC()
# model = clf.fit(img_features,y_train)

# create a RFC model
rfc = RandomForestClassifier()
model = rfc.fit(img_features,y_train,sample_weight=0.9)

# predict
test,tet_descriptors = SURF_img(x_test)

test_features = np.zeros((len(test),100),'float32')
for idx in range(len(test)):
    words, distance = vq(test[idx],vocabulary)
    for w in words:
        test_features[idx][w] += 1

# predictions = clf.predict(test_features)
predictions = rfc.predict(test_features)
acc = 0
for i in range(len(y_test)):
    if y_test[i] == predictions[i]:
        acc += 1
print('Using RandomForestClassifier')
print('The accuracy of prediction: ',acc/ len(y_test))

print(metrics.classification_report(y_test,predictions))
del model
